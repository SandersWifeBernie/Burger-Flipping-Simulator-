s = "      HELLO     "
s = s.lower()
print(s)
